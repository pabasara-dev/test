/**
 * 
 */
package com.mtit.employee;

import java.sql.DriverManager;
import java.util.Properties;

/**
 * this class use config for DB connection.
 * 
 * @author Adithya
 */
public class DbConfig {

	private static final String DRIVER = "driver";
	private static final String PASSWORD = "password";
	private static final String TABLENAME = "tablename";
	private static final String USERNAME = "username";
	private static final String URL = "url";
	private static final String CONFIG_PROPERTIES = "config.properties";

	public static void getDbConnection() {

		Properties property = new Properties();

		try {
			property.load(Main.class.getResourceAsStream(CONFIG_PROPERTIES));// read Properties file
			Class.forName(DRIVER);
			String url = property.getProperty(URL);
			String username = property.getProperty(USERNAME);
			String tablename = property.getProperty(TABLENAME);
			String password = property.getProperty(PASSWORD);

			DriverManager.getConnection(url, username, password);

			System.out.println("You are connected to database through " + url + "as" + username
					+ "user. All your details are stored in " + tablename + "table.");

		} catch (Exception e) {
			e.getStackTrace();
			System.out.println("Error : " + e);

		}
	}

}
