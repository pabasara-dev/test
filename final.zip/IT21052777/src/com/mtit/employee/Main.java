package com.mtit.employee;
/**
 * this class for main program
 * @author ADithya
 */
public class Main {

	private static final double PRESENTAGE = 0.3;
	private static final int OT_RATE = 30;

	public static void main(String[] args) {
		DbConfig.getDbConnection();
		
		Employee employee = new Employee();
		employee.setEmpid(1);
		employee.setEmpname("John");
		employee.setBasic_sal(50000);
		employee.setOt_hrs(2);
		
		double result = calculateNetSalary(employee);
		System.out.println(result);
		
		if (result > 50000) { 
			System.out.println("You are subjected to Tax Payment");
		}
		
		System.out.println("You have to pay a tax of " + calculateTaxAmmount(employee));
		System.out.println("Your salary after deducting tax is " + calc_salaftertax(employee));

	}

	public static double calculateNetSalary(Employee employee) {
		return employee.getBasic_sal() + employee.getOt_hrs() * OT_RATE;//calculate net salary
	}

	public static double calculateTaxAmmount(Employee employee) {
		return calculateNetSalary(employee) * PRESENTAGE; //calculate tax
	}

	public static double calc_salaftertax(Employee employee) {
		double nettotal = calculateNetSalary(employee);
		return nettotal - (nettotal * PRESENTAGE); // calculate final salary
	}

}
