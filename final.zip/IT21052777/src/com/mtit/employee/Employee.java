package com.mtit.employee;
/**
 * class for Employee Object
 */
public class Employee {
	private int empid;
	private String empname;
	private double basic_sal;
	private double ot_hrs;

	public Employee() {
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public double getBasic_sal() {
		return basic_sal;
	}

	public void setBasic_sal(double basic_sal) {
		this.basic_sal = basic_sal;
	}

	public double getOt_hrs() {
		return ot_hrs;
	}

	public void setOt_hrs(double ot_hrs) {
		this.ot_hrs = ot_hrs;
	}
}